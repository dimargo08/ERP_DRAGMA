// Configuración del modo demo: datos simulados en el navegador.
window.__DRAGMA_CONFIG__ = { demo: true, apiUrl: '' };
